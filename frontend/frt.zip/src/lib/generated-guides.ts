// ============================================================================
// GUIDES GÉNÉRÉS AUTOMATIQUEMENT - NE PAS MODIFIER MANUELLEMENT
// Généré le: 2025-11-22T09:40:45.735Z
// Total guides: 12
// ============================================================================

/**
 * Registry des guides YAML générés à partir de content/guides/**
 * Clé = slug du guide (nom du fichier sans .yaml)
 * Valeur = contenu YAML en string
 */
export const GENERATED_GUIDES_REGISTRY: Record<string, string> = {
  'vehicules-garantie-legale-vices-caches.yml': `title: 'Voiture ou scooter défectueux : garantie légale et vices cachés (Guide 2025)'
description: 'Voiture d’occasion, moto, scooter, trottinette : tout véhicule acheté à un professionnel est couvert par la garantie légale de conformité pendant 2 ans. En cas de vice caché ou de refus de prise en charge, découvrez la procédure complète et vos recours.'
category: 'automobile'
slug: 'vehicules-garantie-legale-vices-caches'

seo:
  title: 'Voiture ou véhicule défectueux : vos droits à la réparation, au remplacement ou au remboursement (Guide 2025)'
  description: 'Voiture ou scooter en panne après l’achat ? Garantie légale 2 ans pour les pros, garantie contre les vices cachés pour tous les vendeurs. Réparation, remboursement, ou recours judiciaires : suivez notre guide clair et complet.'
  keywords:
    - 'garantie légale voiture occasion'
    - 'vice caché voiture achat pro'
    - 'garagiste refus réparation'
    - 'moto trottinette panne garantie'
    - 'L217-3 L217-4 L217-5 1641 vice caché'
    - 'refus prise en charge vendeur auto'
    - 'litige garage automobile'

legal:
  mainArticles:
    - 'L.217-3'
    - 'L.217-4'
    - 'L.217-5'
    - 'L.217-7'
    - 'L.217-8'
    - 'L.217-9'
    - 'L.217-10'
    - 'L.217-11'
    - 'L.217-13'
    - 'L.217-14'
    - 'L.217-16'
    - 'L.217-19'
    - '1641'
    - '1644'
    - '1648'
  disclaimer: true
  lastUpdated: '2025-10-30'

sections:
  - id: 'intro'
    title: 'L’essentiel en 30 secondes'
    type: 'content'
    content: |
      Qu’il s’agisse d’une **voiture, moto, scooter ou trottinette**, votre vendeur professionnel doit vous livrer un **véhicule conforme** et en bon état de fonctionnement L.217-3 L.217-4 L.217-5.  
      Si un **défaut mécanique** apparaît dans les **2 ans suivant la vente**, vous pouvez exiger **réparation, remplacement ou remboursement gratuit** L.217-8 L.217-10 L.217-11.  
      Si le défaut est **antérieur à la vente** et **rendant le véhicule impropre à l’usage**, il peut aussi relever des **vices cachés** 1641 du Code civil.

  - id: 'types-defauts'
    title: 'Défauts couverts par la loi'
    type: 'grid'
    items:
      - title: 'Défaut de conformité'
        description: 'Problème présent dès l’achat (ex. : fuite, vibration, voyant moteur, batterie, freins) — la garantie légale s’applique L.217-3 à L.217-14.'
      - title: 'Vice caché'
        description: 'Défaut grave et antérieur à la vente, non apparent et rendant le véhicule inutilisable 1641 à 1648. S’applique même entre particuliers.'
      - title: 'Garantie commerciale'
        description: 'Optionnelle, proposée par le vendeur ou le constructeur. Elle **ne remplace pas** la garantie légale L.217-15.'
      - title: 'Réparation ou prestation non conforme'
        description: 'Si un garage effectue une réparation défaillante, vous pouvez exiger une nouvelle intervention ou un remboursement sur le fondement du **contrat de service** L.217-3 L.217-5.'

  - id: 'procedure'
    title: 'Procédure pas-à-pas'
    type: 'timeline'
    steps:
      - title: 'Diagnostic et preuve du défaut'
        description: |
          Conservez tous les **diagnostics**, **devis**, **factures** et **rapports d’expertise**.  
          Si le défaut survient dans les **24 mois** après achat auprès d’un professionnel, il est **présumé exister dès la vente** L.217-7.  
          Pour un vice caché, une expertise indépendante peut être utile 1641.
      - title: 'Réclamation au vendeur'
        description: |
          Adressez une **réclamation écrite** au vendeur professionnel pour demander la **mise en conformité** du véhicule (réparation ou remplacement gratuit) L.217-8 L.217-11.  
          Mentionnez le délai légal de **30 jours** maximum pour l’exécution L.217-10.
      - title: 'Mise en demeure'
        description: |
          Si le vendeur **refuse ou tarde**, envoyez une **mise en demeure** avec rappel des articles L.217-8 à L.217-14.  
          En cas de vice caché, vous pouvez demander la **résolution du contrat** (annulation de la vente) ou une **réduction du prix** 1644.
      - title: 'Recours amiables ou judiciaires'
        description: |
          Si le litige persiste, saisissez le **médiateur de la consommation** ou la **DGCCRF**.  
          En dernier recours, une **action judiciaire** peut être intentée dans les **2 ans à compter de la découverte du vice** 1648.

  - id: 'vice-cache'
    title: 'Vice caché : vos recours'
    type: 'content'
    content: |
      Un **vice caché** est un défaut **grave, antérieur à la vente et non visible** au moment de l’achat 1641.  
      Vous pouvez choisir entre :  
      - **annuler la vente et rendre le véhicule** (résolution) ;  
      - ou **le garder et obtenir un remboursement partiel** (réduction du prix) 1644.  
      Si vous avez acheté à un **professionnel**, il est **présumé connaître les vices** et ne peut pas s’en exonérer.  
      Le délai pour agir est de **2 ans après la découverte du vice** 1648.

  - id: 'cas-frequents'
    title: 'Cas fréquents'
    type: 'faq'
    faqItems:
      - q: 'Mon véhicule d’occasion tombe en panne après 3 mois'
        a: 'La panne est **présumée antérieure** L.217-7. Le vendeur professionnel doit réparer ou remplacer sans frais L.217-8 L.217-11.'
      - q: 'Le garage refuse de reconnaître le vice caché'
        a: 'Une **expertise indépendante** peut prouver l’antériorité du défaut 1641. Ensuite, une mise en demeure puis une action judiciaire sont possibles 1648.'
      - q: 'Le vendeur me renvoie vers la garantie du constructeur'
        a: 'C’est interdit : la garantie légale de conformité engage le **vendeur** L.217-3. Vous pouvez refuser de passer par la marque.'
      - q: 'J’ai acheté à un particulier'
        a: 'La garantie légale ne s’applique pas, mais vous pouvez agir sur le fondement du **vice caché** 1641 à 1648.'

  - id: 'garages'
    title: 'Litiges avec un garage'
    type: 'content'
    content: |
      Un garage a une **obligation de résultat** pour les réparations qu’il effectue.  
      Si le véhicule tombe à nouveau en panne ou si la prestation est mal réalisée, vous pouvez exiger une **nouvelle intervention gratuite** ou un **remboursement** L.217-3 L.217-5.  
      En cas de refus, envoyez une **mise en demeure**, puis saisissez le **conciliateur de justice** ou le **médiateur de l’automobile**.

  - id: 'recommandations'
    title: 'Bon à savoir'
    type: 'content'
    content: |
      - Les **véhicules d’occasion** vendus par des professionnels sont couverts 2 ans, mais la **présomption** est limitée à **12 mois** L.217-7.  
      - Les **frais de réparation, main-d’œuvre et pièces** sont à la charge du vendeur L.217-11.  
      - Une **expertise amiable ou judiciaire** est souvent décisive pour prouver le vice caché 1641.  
      - La garantie légale est **indépendante** des garanties commerciales ou constructeurs.

  - id: 'cta'
    title: 'Faites valoir vos droits'
    type: 'content'
    content: |
      Générez gratuitement votre **mise en demeure** ou **réclamation** automobile, avec insertion automatique des **articles de loi** applicables.  
      Version **PDF professionnelle** et **envoi recommandé** disponibles.
    cta:
      label: 'Rédiger ma mise en demeure'
      href: '/outils/mise-en-demeure'
      variant: 'primary'
      icon: 'FileText'

  - id: 'contacts'
    title: 'Contacts utiles'
    type: 'contacts'

  - id: 'disclaimer'
    title: 'Important'
    type: 'content'
    content: |
      Ce guide résume vos droits en matière d’**achats et réparations automobiles** selon le Code de la consommation et le Code civil.  
      Il **ne constitue pas un conseil juridique individualisé**.  
      En cas de litige complexe, rapprochez-vous d’un **avocat spécialisé en droit automobile** ou d’une **association de consommateurs**.

`,
  'grandes-enseignes-et-marketplaces.yml': `title: 'Amazon, Fnac, Darty, Cdiscount… Vos droits face aux grandes enseignes (Guide 2025)'
description: 'En cas de produit défectueux ou de refus de garantie, vos droits dépendent du vendeur réel, pas de la plateforme. Découvrez comment agir sur Amazon, Fnac, Darty, Cdiscount, Back Market, et autres marketplaces.'
category: 'commerce'
slug: 'grandes-enseignes-et-marketplaces'

seo:
  title: 'Amazon, Fnac, Darty, Cdiscount : garantie légale et vendeur réel (Guide 2025)'
  description: 'Produit défectueux ou refus de prise en charge ? Le vendeur est légalement responsable, même sur une marketplace. Découvrez comment identifier le vendeur, réclamer réparation ou remboursement, et agir si la plateforme bloque.'
  keywords:
    - 'Amazon garantie légale'
    - 'Fnac marketplace vendeur tiers'
    - 'Cdiscount refus garantie'
    - 'Darty réparation produit défectueux'
    - 'Back Market smartphone reconditionné'
    - 'vendeur tiers marketplace recours'
    - 'L217-3 L217-5 L217-10 garantie conformité'
    - 'marketplace DGCCRF signalement'

legal:
  mainArticles:
    - 'L.217-3'
    - 'L.217-4'
    - 'L.217-5'
    - 'L.217-7'
    - 'L.217-8'
    - 'L.217-10'
    - 'L.217-11'
    - 'L.217-13'
    - 'L.221-5'
    - 'L.221-18'
    - 'L.221-23'
    - 'L.221-28'
    - 'L.242-3'
    - 'L.242-4'
  disclaimer: true
  lastUpdated: '2025-10-24'

sections:
  - id: 'intro'
    title: 'L’essentiel en 30 secondes'
    type: 'content'
    content: |
      Sur une plateforme comme **Amazon, Fnac, Cdiscount, Darty ou Back Market**, votre **interlocuteur légal** est toujours le **vendeur réel**, qu’il s’agisse de la plateforme elle-même ou d’un **vendeur tiers**.  
      Ce vendeur est tenu de livrer un produit **conforme au contrat** L.217-3 L.217-4 L.217-5.  
      En cas de défaut, vous pouvez exiger **réparation, remplacement ou remboursement gratuit** L.217-8 L.217-10 L.217-11.  
      La plateforme doit indiquer **clairement l’identité du vendeur** L.221-5 et faciliter la communication en cas de litige.

  - id: 'identifier-vendeur'
    title: 'Identifier le vendeur réel'
    type: 'timeline'
    steps:
      - title: 'Vérifiez la fiche produit'
        description: |
          Sous le bouton d’achat, cherchez la mention “Vendu par…”.  
          - Si c’est “Amazon” ou “Darty”, la **plateforme est le vendeur**.  
          - Si c’est “XYZ Trading” ou “StorePro”, c’est un **vendeur tiers** hébergé sur la marketplace.  
          Ce vendeur reste responsable de la conformité du produit L.217-3.
      - title: 'Vérifiez le pays d’établissement'
        description: |
          Les vendeurs basés **hors de l’Union européenne** ne sont pas soumis aux mêmes obligations, mais la plateforme doit vous en informer clairement L.221-5.  
          En cas de litige, cela peut compliquer la procédure — d’où l’intérêt d’acheter auprès d’un **vendeur établi en France ou dans l’UE**.
      - title: 'Contactez le bon service'
        description: |
          - Si le vendeur est la plateforme elle-même : utilisez son **SAV officiel**.  
          - Si c’est un vendeur tiers : contactez-le via la **messagerie interne** de la plateforme (Amazon, Fnac, Back Market, etc.).  
          Mentionnez la **garantie légale de conformité** L.217-3 à L.217-14 et gardez une **preuve écrite** de vos échanges.

  - id: 'droits'
    title: 'Vos droits en cas de produit défectueux'
    type: 'grid'
    items:
      - title: 'Garantie légale de conformité'
        description: 'Applicable pendant **2 ans à compter de la livraison** L.217-3 L.217-7. Vous pouvez exiger **réparation ou remplacement gratuit** puis, à défaut, **réduction du prix ou remboursement** L.217-8 à L.217-11.'
      - title: 'Garantie commerciale ou constructeur'
        description: 'Offerte parfois par la marque, elle s’ajoute à la garantie légale mais ne la remplace pas. Elle doit être **écrite et claire** L.217-21. Vous êtes libre de choisir entre les deux.'
      - title: 'Droit de rétractation'
        description: 'Pour les achats à distance, vous pouvez **vous rétracter sous 14 jours** sans motif L.221-18, sauf produits personnalisés ou descellés L.221-28.'
      - title: 'Frais de retour'
        description: 'Si le produit est défectueux, **tous les frais de retour sont à la charge du vendeur** L.217-11. En cas de simple rétractation, ils peuvent être à votre charge si indiqué clairement L.221-23.'

  - id: 'marketplaces'
    title: 'Responsabilités des plateformes'
    type: 'content'
    content: |
      Les marketplaces (Amazon, Fnac, Cdiscount, Back Market, etc.) doivent garantir une **information claire et loyale** L.221-5.  
      Elles doivent notamment :
      - indiquer **l’identité du vendeur tiers**,  
      - préciser si celui-ci est un **professionnel ou un particulier**,  
      - et afficher les **conditions de livraison, garantie et retour** avant l’achat.  
      Si la plateforme **intervient activement** (stockage, expédition, paiement, service client), elle peut être considérée **codéfautrice** et **coresponsable** de la non-conformité L.242-3 L.242-4.

  - id: 'procedure'
    title: 'Procédure en cas de litige'
    type: 'timeline'
    steps:
      - title: 'Réclamation au vendeur'
        description: |
          Commencez par une **réclamation écrite** via le service client ou la messagerie interne.  
          Citez la **garantie légale de conformité** L.217-3 à L.217-14 et exigez une **mise en conformité sous 30 jours** L.217-10.  
          Joignez la facture et des preuves (photos, description du défaut).
      - title: 'Intervention de la plateforme'
        description: |
          Si le vendeur tiers ne répond pas, la plateforme doit faciliter la résolution du litige L.242-4.  
          Sur Amazon, par exemple, le programme **A-to-Z Guarantee** peut vous rembourser directement.  
          Sur Back Market, un **service de médiation interne** est disponible.
      - title: 'Médiation ou tribunal'
        description: |
          Si le vendeur ou la plateforme refuse d’agir, vous pouvez saisir un **médiateur de la consommation** L.612-1 L.616-1 ou, en dernier recours, le **tribunal judiciaire** R.631-3.  
          Vous pouvez y demander **remboursement, dommages et intérêts ou exécution forcée**.

  - id: 'retractation'
    title: 'Cas particuliers du droit de rétractation'
    type: 'faq'
    faqItems:
      - q: 'J’ai ouvert le produit, puis-je encore me rétracter ?'
        a: 'Oui, sauf si le produit est descellé pour des raisons d’hygiène ou de protection (ex. écouteurs, sous-vêtements) L.221-28.'
      - q: 'Et pour un contenu numérique téléchargé ?'
        a: 'Le droit de rétractation est **perdu dès le téléchargement**, si vous avez donné votre accord préalable explicite L.221-28.'
      - q: 'Le vendeur me fait payer le retour alors que le produit est défectueux'
        a: 'C’est illégal : les **frais de retour doivent être pris en charge par le vendeur** L.217-11.'
      - q: 'La plateforme refuse de m’aider car c’est un vendeur tiers'
        a: 'Rappelez qu’elle a un **devoir d’assistance et d’information loyale** L.242-3 L.242-4, surtout si elle gère la logistique ou le paiement.'

  - id: 'reconditionne'
    title: 'Cas du reconditionné'
    type: 'content'
    content: |
      Les produits reconditionnés (Back Market, Fnac Seconde Vie, Amazon Renewed, etc.) bénéficient des **mêmes droits que les neufs**, mais la **présomption de conformité** est limitée à **12 mois** L.217-7.  
      Vous conservez la garantie légale de conformité complète : **réparation, remplacement, réduction du prix ou remboursement** L.217-8 à L.217-11.  
      Vérifiez que le vendeur indique bien “professionnel” et non “particulier”, car la loi ne protège pas les achats entre particuliers.

  - id: 'cta'
    title: 'Faites valoir vos droits en ligne'
    type: 'content'
    content: |
      En quelques minutes, générez votre **réclamation ou mise en demeure** adaptée à Amazon, Fnac, Cdiscount, Darty ou Back Market.  
      Le texte intègre automatiquement les **articles du Code de la consommation** et le nom du vendeur réel.  
      Version **PDF** et **envoi recommandé** disponibles.
    cta:
      label: 'Générer ma réclamation'
      href: '/outils/mise-en-demeure'
      variant: 'primary'
      icon: 'FileText'

  - id: 'contacts'
    title: 'Contacts utiles'
    type: 'contacts'

  - id: 'disclaimer'
    title: 'Important'
    type: 'content'
    content: |
      Ce guide présente les **droits des consommateurs sur les marketplaces et sites de vente en ligne**, selon le Code de la consommation.  
      Il **ne remplace pas** un avis juridique individualisé.  
      En cas de doute, contactez une **association agréée** ou un **professionnel du droit**.

`,
  'garantie-legale-conformite-guide-complet': `title: 'Garantie légale de conformité : le guide de référence 2025'
description: 'Comprendre et activer vos droits : 2 ans de protection (24 mois neuf / 12 mois occasion pour la présomption), mise en conformité ≤ 30 jours, 0 € de frais, réparations/remplacement, réduction du prix ou résolution. Outils gratuits + LRAR en 1 clic.'
category: 'general'
slug: 'garantie-legale-conformite-guide-complet'

seo:
  title: 'Garantie légale de conformité 2025 (France) : droits, délais 30 jours, modèles et procédure (Guide complet)'
  description: 'Le guide le plus complet : critères de conformité, présomption 24/12 mois, mise en conformité ≤ 30 jours, aucun frais, réduction/résolution (art. L.217-3 à L.217-20). Modèles, outils gratuits, LRAR en 1 clic, relance auto.'
  keywords:
    - 'garantie légale de conformité'
    - 'garantie 2 ans France'
    - 'présomption 24 mois 12 mois occasion'
    - 'mise en conformité 30 jours'
    - ' L.217-9 réparation remplacement'
    - ' L.217-10 délai 30 jours'
    - " L.217-11 aucun frais valeur d'usage"
    - ' L.217-14 réduction du prix résolution'
    - ' L.217-19 mises à jour numériques'
    - 'modèle mise en demeure gratuit'
    - 'envoyer recommandé en ligne'
    - 'droits consommateur France'
    - 'vendeur refuse garantie légale'

legal:
  mainArticles:
    [
      ' L.217-3',
      ' L.217-5',
      ' L.217-7',
      ' L.217-8',
      ' L.217-9',
      ' L.217-10',
      ' L.217-11',
      ' L.217-12',
      ' L.217-13',
      ' L.217-14',
      ' L.217-15',
      ' L.217-16',
      ' L.217-17',
      ' L.217-19',
      ' L.212-1',
    ]
  disclaimer: true
  lastUpdated: '2025-09-16'

sections:
  - id: 'intro'
    title: 'Pourquoi ce guide peut vraiment vous aider'
    icon: 'Search'
    type: 'content'
    content: |
      Vous avez acheté un produit auprès d'un professionnel et un défaut apparaît, ou la réalité ne correspond pas à la fiche produit ? La **garantie légale de conformité** existe précisément pour cela. Elle oblige le **vendeur** (et non seulement le constructeur) à livrer un bien conforme à la description et à l'usage attendu. Concrètement, cela se traduit par une **mise en conformité** – **réparation** ou **remplacement** – dans un délai **raisonnable**, qui **ne peut pas dépasser 30 jours**, et **sans aucun frais** pour vous.

      Ce guide est conçu pour **clarifier l'essentiel**, **rentrer dans le détail** sans vous perdre, et **vous faire gagner du temps** : vous allez comprendre vos droits, savoir **quoi demander** et **comment l'obtenir**.

    alert:
      type: 'info'
      title: 'Conseil pratique'
      content: "Ce guide couvre tous les aspects de la garantie légale de conformité. Vous pouvez naviguer directement vers la section qui vous intéresse ou le lire dans l'ordre pour une compréhension complète."

    badges:
      - text: 'Guide officiel 2025'
        tone: 'blue'
      - text: 'Mis à jour'
        tone: 'green'
      - text: 'Juridiquement vérifié'
        tone: 'purple'

    cta:
      label: 'Tester mon éligibilité'
      href: '/eligibilite'
      icon: 'ChevronRight'
      variant: 'primary'

  - id: 'definition'
    title: "Qu'est-ce que la garantie légale de conformité ?"
    icon: 'BookOpen'
    type: 'content'
    content: |
      La **garantie légale de conformité** est une protection automatique et gratuite qui s'applique à tous les achats auprès de professionnels en France. Elle vous protège contre les défauts de conformité pendant **2 ans** pour les biens neufs et **1 an** pour les biens d'occasion.

      ### Les critères de conformité L.217-5

      Un bien est considéré comme conforme s'il répond aux critères suivants :

      1. **Correspondance à la description** donnée par le vendeur
      2. **Aptitude à l'usage** habituellement attendu
      3. **Présentation des qualités** annoncées par le vendeur
      4. **Présentation des qualités** qu'un acheteur peut légitimement attendre

      ### Présomption de non-conformité
      Le vendeur a la charge de la preuve : dans les délais ci-dessous, c'est à lui d'apporter des preuves de la conformité du bien. Vous n'avez rien à prouver.
      - **24 mois** pour les biens neufs L.217-7
      - **12 mois** pour les biens d'occasion L.217-7

      Pendant cette période, si un défaut apparaît, il est **présumé** exister au moment de la vente. C'est au vendeur de prouver le contraire.

    alert:
      type: 'success'
      title: 'Important à retenir'
      content: 'Contrairement à la garantie commerciale, la garantie légale est **gratuite**, **automatique** et ne peut pas être refusée par le vendeur.'

  - id: 'droits'
    title: 'Vos droits en cas de non-conformité'
    icon: 'Scale'
    type: 'timeline'
    content: |
      Lorsqu'un défaut de conformité est constaté, vous avez **le choix** entre deux solutions principales L.217-9 :

      ### Réparation ou remplacement (mise en conformité)

      **Conditions à respecter par le vendeur :**
      - **Délai raisonnable** qui ne peut **pas dépasser 30 jours** L.217-10
      - **Aucun frais** pour vous : ni main d'œuvre, ni pièces, ni transport L.217-11
      - **Aucune inconvénient majeur** pour vous L.217-11

      **Vous gardez le bien** pendant la réparation, sauf si son état ne le permet pas.

      ### Si la mise en conformité échoue

      Si la réparation/remplacement est **impossible**, **trop coûteuse** ou **échoue**, vous pouvez demander L.217-14 :

      - **Réduction du prix** proportionnelle au défaut
      - **Résolution de la vente** (remboursement) si le défaut est suffisamment grave

      ### Cas particuliers

      - **Biens numériques :** Droit aux mises à jour pendant la durée d'usage attendue L.217-19

    cta:
      label: 'Créer ma lettre de mise en demeure'
      href: '/eligibilite'
      icon: 'FileText'
      variant: 'primary'

  - id: 'procedure'
    title: 'Comment faire valoir vos droits : la procédure complète'
    icon: 'CheckSquare'
    type: 'timeline'
    content: |
      ### Rassembler les preuves

      **Documents indispensables :**
      - Facture ou preuve d'achat
      - Photos/vidéos du défaut
      - Correspondence avec le vendeur
      - Notice du produit ou fiche technique

      **Preuves complémentaires :**
      - Témoignages d'utilisation normale
      - Devis de réparation d'un professionnel
      - Documentation technique du constructeur

      ### Première demande amiable

      - **Privilégier l'écrit :** Email ou courrier simple en recommandé
      - **Délai de réponse :** Laisser 15 jours ouvrés
      - **Ton :** Ferme mais courtois

      ### Mise en demeure formelle

      Si le vendeur refuse ou ne répond pas :

      **Contenu obligatoire :**
      - Référence aux articles de loi L.217-9 L.217-10 L.217-11
      - Description précise du défaut
      - Demande claire (réparation/remplacement)
      - Délai de 30 jours maximum
      - Mention des conséquences en cas de refus

      **Envoi :** Lettre recommandée avec accusé de réception

      ### Recours en cas d'échec

      - **Médiation de la consommation** (gratuite)
      - **Tribunal judiciaire** pour les litiges > 5 000 €
      - **Tribunal de proximité** pour les litiges ≤ 5 000 €

    alert:
      type: 'warning'
      title: 'Attention aux délais'
      content: "La garantie légale s'exerce dans un délai de **2 ans** (1 an pour l'occasion) à compter de la délivrance du bien. Ne tardez pas à agir !"

  - id: 'outils'
    title: 'Nos outils pour vous accompagner'
    icon: 'Wrench'
    type: 'content'
    content: |
      ### Test d'éligibilité gratuit

      En quelques questions, déterminez si votre situation relève de la garantie légale de conformité et identifiez la meilleure stratégie.

      ### Générateur de lettres automatique

      - **Version gratuite :** Lettre type à personnaliser et imprimer
      - **Version pro :** PDF professionnel signé en ligne et prêt à imprimer
      - **Version premium :** PDF professionnel + envoi en LRAR + suivi

      ### Suivi de votre dossier

      Relances automatiques, et des guides adaptés pour la suite.

    cta:
      label: 'Commencer maintenant'
      href: '/eligibilite'
      icon: 'ArrowRight'
      variant: 'primary'

  - id: 'conclusion'
    title: "En résumé : ce qu'il faut retenir"
    icon: 'CheckCircle'
    type: 'content'
    content: |
      La garantie légale de conformité est **votre droit le plus puissant** face aux défauts de produits achetés chez des professionnels.

      **Les points clés à retenir :**

      - **2 ans de protection** (1 an pour l'occasion)  
      - **Présomption automatique** pendant 24/12 mois 
      - **Mise en conformité gratuite** en moins de 30 jours  
      - **Aucun frais** à votre charge  
      - **Choix** entre réparation et remplacement  
      - **Recours** en cas d'échec (réduction/remboursement)

      **Notre valeur ajoutée :**

      Plutôt que de vous lancer seul dans une procédure complexe, nos outils transforment vos droits en **démarches concrètes** : diagnostic immédiat, lettre juridiquement solide, envoi sécurisé et suivi jusqu'à la résolution.

      Résultat : vous gagnez du temps, vous sécurisez vos droits, et vous maximisez vos chances d'une solution **rapide** et **conforme à la loi**.

    alert:
      type: 'success'
      title: '🚀 Prêt à agir ?'
      content: 'Votre situation nécessite une action ? Utilisez nos outils pour transformer vos droits en résultats concrets.'

    cta:
      label: 'Tester mon éligibilité gratuitement'
      href: '/eligibilite'
      icon: 'Zap'
      variant: 'primary'
`,
  'recours-apres-mise-en-demeure.yml': `title: 'Recours si la mise en demeure reste sans réponse (Guide 2025)'
description: 'Le vendeur ignore votre mise en demeure ? Vous pouvez saisir un médiateur, alerter la DGCCRF, faire intervenir votre protection juridique ou engager une action devant le tribunal. Explications pas-à-pas.'
category: 'general'
slug: 'recours-apres-mise-en-demeure'

seo:
  title: 'Vendeur silencieux ou refus de garantie : que faire après une mise en demeure ?'
  description: 'Votre courrier recommandé reste sans réponse ? Découvrez les recours légaux : médiation gratuite, signalement DGCCRF, protection juridique ou tribunal judiciaire. Guide complet et accessible.'
  keywords:
    - 'mise en demeure sans réponse'
    - 'vendeur refuse garantie que faire'
    - 'médiation consommation recours'
    - 'DGCCRF signalement'
    - 'tribunal judiciaire consommation'
    - 'protection juridique assurance'
    - 'litige achat non résolu'
    - 'plainte vendeur litige'

legal:
  mainArticles:
    - 'L.217-3'
    - 'L.217-10'
    - 'L.217-13'
    - 'L.612-1'
    - 'L.616-1'
    - 'R.631-3'
    - '1641'
    - '1648'
  disclaimer: true
  lastUpdated: '2025-10-21'

sections:
  - id: 'intro'
    title: 'Quand le vendeur ignore votre mise en demeure'
    type: 'content'
    content: |
      Vous avez envoyé une **mise en demeure** pour faire appliquer la **garantie légale de conformité** L.217-3 à L.217-14, mais le vendeur **ne répond pas**, **refuse** ou **retarde** la réparation ?  
      La loi prévoit plusieurs **recours progressifs**, pour faire valoir vos droits sans forcément passer immédiatement par un avocat.

  - id: 'recours-amiables'
    title: 'Les solutions amiables à tenter d’abord'
    type: 'timeline'
    steps:
      - title: 'Relance écrite ou téléphonique'
        description: |
          Rappelez brièvement la date de votre mise en demeure, le délai écoulé, et citez vos droits issus de la garantie légale L.217-10 L.217-13.  
          Un rappel courtois et documenté suffit souvent à faire réagir un service client.
      - title: 'Saisir le médiateur de la consommation'
        description: |
          Tout professionnel doit permettre la **médiation de la consommation**, gratuite pour le client L.612-1 L.616-1.  
          La demande s’effectue **en ligne**, auprès du médiateur mentionné dans les CGV ou sur le site du vendeur.  
          Le médiateur rend un avis sous **90 jours**. Ce n’est pas une obligation pour vous, mais le vendeur doit l’examiner.
      - title: 'Contacter un conciliateur de justice'
        description: |
          Si la médiation échoue ou reste sans suite, saisissez un **conciliateur de justice** R.631-3.  
          C’est un service **gratuit**, assuré par un bénévole assermenté, qui tente de rapprocher les parties avant un procès.  
          Rendez-vous sur [www.conciliateurs.fr](https://www.conciliateurs.fr) ou auprès du tribunal judiciaire le plus proche.

  - id: 'protection-juridique'
    title: 'Faire intervenir votre protection juridique'
    type: 'content'
    content: |
      Vérifiez vos **contrats d’assurance habitation, auto ou carte bancaire** : beaucoup incluent une **protection juridique**.  
      Elle peut financer :
      
      - une **expertise indépendante**,  
      - un **avocat** si une procédure est nécessaire,  
      - ou la **rédaction de courriers juridiques**.  
      Contactez votre assureur pour activer cette garantie dès le premier refus du vendeur.

  - id: 'signalement'
    title: 'Signaler le professionnel à la DGCCRF'
    type: 'content'
    content: |
      En cas de refus abusif ou de **fausse information sur vos droits**, faites un **signalement** à la DGCCRF via [SignalConso.gouv.fr](https://signal.conso.gouv.fr).  
      L’administration contacte le professionnel pour l’inviter à se mettre en conformité.  
      Ce n’est pas une plainte individuelle, mais cela peut faire **bouger le vendeur** ou déclencher un **contrôle**.

  - id: 'expertise'
    title: 'Faire établir une expertise'
    type: 'content'
    content: |
      Si le vendeur conteste le défaut, demandez une **expertise contradictoire** pour prouver l’origine du problème.  
      Un **expert agréé** (technicien, huissier, expert judiciaire) pourra confirmer que le défaut existait avant la vente.  
      Ce rapport servira de preuve pour un **vice caché** 1641 1648 ou une action au **tribunal judiciaire** R.631-3.

  - id: 'tribunal'
    title: 'Saisir le tribunal judiciaire'
    type: 'timeline'
    steps:
      - title: 'Vérifier la tentative amiable'
        description: |
          Pour un litige inférieur à 5 000 €, la loi impose d’avoir tenté une **médiation ou conciliation préalable** R.631-3.  
          Si vous avez envoyé une mise en demeure et saisi un médiateur, cette condition est remplie.
      - title: 'Saisine du tribunal judiciaire'
        description: |
          Le tribunal compétent est celui de **votre domicile** R.631-3.  
          Vous pouvez saisir le tribunal **en ligne** sur [www.justice.fr](https://www.justice.fr) ou directement au greffe.  
          Aucun avocat n’est requis pour les montants inférieurs à 5 000 €, mais son aide peut être utile en cas d’expertise.
      - title: 'Décision et exécution'
        description: |
          Le juge peut ordonner la **réparation**, le **remboursement** ou des **dommages et intérêts**.  
          Si le vendeur ne s’exécute pas, la décision est **exécutoire par un huissier**.  
          Les jugements fondés sur les articles L.217-3 à L.217-14 du Code de la consommation sont très protecteurs pour les consommateurs.

  - id: 'associations'
    title: 'Se faire accompagner'
    type: 'grid'
    itemsIntro: 'Des organismes peuvent vous aider gratuitement à finaliser vos démarches :'
    items:
      - title: 'Associations agréées'
        description: 'UFC-Que Choisir, CLCV, ADEIC ou Familles Rurales : conseils juridiques, rédaction de courriers, médiation, accompagnement tribunal.'
      - title: 'Maisons de justice et du droit'
        description: 'Consultations gratuites de juristes et avocats pour préparer votre dossier.'
      - title: 'Conciliateurs de justice'
        description: 'Bénévoles assermentés pouvant intervenir avant tout procès pour tenter un accord amiable.'

  - id: 'cta'
    title: 'Passez à l’action'
    type: 'content'
    content: |
      📄 Votre mise en demeure est restée sans réponse ?  
      Générez gratuitement votre **saisine du médiateur** ou votre **demande au tribunal** avec nos modèles juridiques à jour.  
      Versions **PDF** et **recommandé avec suivi** disponibles, avec **support mail illimité**.
    cta:
      label: 'Préparer mon recours'
      href: '/outils/recours'
      variant: 'primary'
      icon: 'FileText'

  - id: 'contacts'
    title: 'Contacts utiles'
    type: 'contacts'

  - id: 'disclaimer'
    title: 'Important'
    type: 'content'
    content: |
      Ce guide présente les **recours légaux** prévus par le Code de la consommation, le Code civil et le Code de procédure civile.  
      Il **ne constitue pas** un conseil juridique individualisé.  
      Pour un dossier complexe, contactez une **association agréée** ou un **professionnel du droit**.

`,
  'recours-non-eligible.yml': `title: 'Vos recours si la garantie légale ne s’applique pas (Guide 2025)'
description: 'Garantie expirée, achat entre particuliers ou casse accidentelle ? D’autres recours existent : vices cachés, médiation, associations de consommateurs, DGCCRF, protection juridique ou tribunal. Procédure claire et gratuite.'
category: 'general'
slug: 'recours-si-non-eligible'

seo:
  title: 'Vices cachés, médiation, DGCCRF : vos recours si la garantie légale ne s’applique pas'
  description: 'Même sans garantie, vous avez des droits : action pour vice caché, médiation gratuite, signalement DGCCRF, protection juridique, aide d’une association ou d’un conciliateur. Toutes les solutions expliquées pas-à-pas.'
  keywords:
    - 'vice caché recours consommateur'
    - 'garantie expirée que faire'
    - 'DGCCRF signalement vendeur'
    - 'médiateur de la consommation procédure'
    - 'conciliation tribunal judiciaire'
    - 'association de consommateurs aide'
    - 'protection juridique assurance'
    - 'litige achat entre particuliers'
    - 'plainte vendeur refus remboursement'

legal:
  mainArticles:
    - 'L.217-3'
    - '1641'
    - '1648'
    - 'L.612-1'
    - 'L.616-1'
    - 'L.611-1'
    - 'R.612-2'
    - 'R.631-3'
  disclaimer: true
  lastUpdated: '2025-10-20'

sections:
  - id: 'intro'
    title: 'Quand la garantie légale ne s’applique pas'
    type: 'content'
    content: |
      Si votre produit n’est **plus couvert par la garantie légale de conformité** L.217-3 à L.217-14 (par exemple en cas de casse accidentelle, d’achat entre particuliers ou de défaut hors délai), vous conservez **d’autres droits prévus par la loi**.  
      Plusieurs solutions amiables et judiciaires existent selon la situation et la gravité du problème.  
      Ce guide vous présente les **recours possibles**, du plus simple au plus formel.

  - id: 'recours-amiables'
    title: 'Les recours amiables à privilégier'
    type: 'timeline'
    steps:
      - title: 'Contacter le service client ou le vendeur'
        description: |
          Même hors garantie, un vendeur peut proposer un **geste commercial** ou une **réparation partielle**.  
          Soyez factuel, courtois, et mentionnez que vous cherchez une **solution amiable**.  
          En cas de refus ou d’absence de réponse, passez à l’étape suivante.
      - title: 'Saisir le médiateur de la consommation'
        description: |
          Tout professionnel doit permettre à ses clients de saisir **gratuitement** un **médiateur de la consommation** L.612-1 L.616-1.  
          Cette démarche écrite se fait **en ligne**, sur le site du médiateur mentionné dans les conditions générales de vente ou sur le site du vendeur.  
          Le médiateur rend un avis sous **90 jours**. Cet avis n’est **pas contraignant**, mais il encourage souvent une solution rapide.
      - title: 'Contacter un conciliateur de justice'
        description: |
          Si la médiation échoue ou n’est pas possible, saisissez un **conciliateur de justice** (gratuit) au tribunal judiciaire de votre domicile R.631-3.  
          Il vous aide à trouver un **accord amiable** avant toute action en justice.  
          Vous pouvez le contacter en ligne sur [www.justice.fr](https://www.justice.fr).

  - id: 'vice-cache'
    title: 'Si le produit présente un vice caché'
    type: 'content'
    content: |
      Vous pouvez invoquer la **garantie des vices cachés** prévue par le Code civil 1641.  
      Un vice caché est un **défaut grave**, **non apparent au moment de l’achat** et **antérieur à la vente**, qui rend le bien **impropre à son usage** ou en **réduit fortement l’utilité**.  
      Vous pouvez :
      - **rendre le bien** et obtenir un **remboursement total**, ou  
      - **le conserver** et obtenir un **remboursement partiel** du prix.  
      Le recours doit être exercé **dans les deux ans après la découverte du défaut** 1648.  
      Une **expertise indépendante** (technicien, huissier, expert agréé) peut appuyer votre demande.

  - id: 'signalement'
    title: 'Signaler un professionnel à la DGCCRF'
    type: 'content'
    content: |
      En cas de **refus abusif**, de **mensonge sur la garantie** ou de **pratiques trompeuses**, vous pouvez faire un **signalement à la DGCCRF** via [SignalConso.gouv.fr](https://signal.conso.gouv.fr).  
      L’administration contacte le professionnel pour l’inviter à corriger la situation.  
      Cela ne remplace pas un recours individuel, mais peut **favoriser une résolution rapide** et **prévenir d’autres abus**.

  - id: 'associations'
    title: 'Être accompagné par une association'
    type: 'grid'
    itemsIntro: 'Des associations agréées peuvent vous aider à comprendre vos droits et à rédiger vos démarches :'
    items:
      - title: 'UFC-Que Choisir'
        description: 'Accompagnement à la **rédaction de courriers**, **médiation**, et **actions collectives** possibles.'
      - title: 'CLCV (Consommation, Logement et Cadre de Vie)'
        description: 'Conseils juridiques, accompagnement individuel et défense des consommateurs dans les litiges avec les vendeurs.'
      - title: 'Familles Rurales, ADEIC, AFOC…'
        description: 'Associations agréées pouvant proposer des **permanences juridiques gratuites** et un appui dans vos démarches.'

  - id: 'protection-juridique'
    title: 'Faire jouer votre protection juridique'
    type: 'content'
    content: |
      Vérifiez vos **contrats d’assurance** (habitation, automobile, carte bancaire, mutuelle) : beaucoup incluent une **protection juridique**.  
      Elle peut couvrir :
      - la **rédaction de courriers juridiques**,  
      - la **prise en charge d’une expertise**,  
      - les **frais d’avocat** en cas de litige.  
      Contactez votre assureur pour savoir si votre litige est **éligible** et quelle couverture s’applique.

  - id: 'recours-judiciaire'
    title: 'Si aucun accord n’est trouvé'
    type: 'timeline'
    steps:
      - title: 'Dernière mise en demeure'
        description: |
          Avant toute action, envoyez une **mise en demeure par lettre recommandée avec accusé de réception**, en rappelant les articles applicables (L.612-1, 1641, 1648) et en fixant un **délai clair** de réponse.
      - title: 'Saisir le tribunal judiciaire'
        description: |
          Si le vendeur ne réagit pas, saisissez le **tribunal judiciaire** de votre domicile R.631-3.  
          Pour un litige inférieur à 5 000 €, la procédure est **gratuite et sans avocat obligatoire**.  
          Vous pouvez déposer votre dossier **en ligne** sur [www.justice.fr](https://www.justice.fr) ou au **greffe du tribunal**.

  - id: 'contacts'
    title: 'Contacts utiles'
    type: 'contacts'

  - id: 'disclaimer'
    title: 'Important'
    type: 'content'
    content: |
      Ce guide présente les **recours légaux et amiables** prévus par le Code de la consommation et le Code civil.  
      Il **ne remplace pas** un conseil juridique personnalisé.  
      En cas de doute, consultez une **association agréée** ou un **professionnel du droit**.

`,
  'electromenager-garantie-legale.yml': `title: 'Électroménager en panne : réparation, remplacement ou remboursement gratuit (Guide 2025)'
description: 'Lave-linge, frigo, aspirateur, robot, four, sèche-linge, lave-vaisselle… Tous vos appareils sont couverts par la garantie légale de conformité pendant 2 ans. Découvrez vos droits, la procédure et les recours possibles.'
category: 'maison'
slug: 'electromenager-garantie-legale'

seo:
  title: 'Panne d’électroménager : vos droits à la réparation ou au remboursement (Guide 2025)'
  description: 'Appareil en panne avant 2 ans ? Vous bénéficiez de la garantie légale de conformité. Réparation, remplacement ou remboursement gratuit selon les articles L.217-3 à L.217-14. Guide complet + modèles de lettres.'
  keywords:
    - 'électroménager panne garantie légale'
    - 'lave-linge frigo four réparation gratuite'
    - 'remboursement appareil défectueux'
    - 'garantie légale 2 ans électroménager'
    - 'indice réparabilité L111-4 L217-5'
    - 'vendeur refuse réparation conformité'
    - 'réduction du prix résolution contrat'

legal:
  mainArticles:
    - 'L.217-3'
    - 'L.217-4'
    - 'L.217-5'
    - 'L.217-7'
    - 'L.217-8'
    - 'L.217-9'
    - 'L.217-10'
    - 'L.217-11'
    - 'L.217-13'
    - 'L.217-14'
    - 'L.217-16'
    - 'L.217-19'
    - 'L.111-4'
  disclaimer: true
  lastUpdated: '2025-10-29'

sections:
  - id: 'intro'
    title: 'L’essentiel en 30 secondes'
    type: 'content'
    content: |
      Votre lave-linge, réfrigérateur, aspirateur ou robot tombe en panne ?  
      La **garantie légale de conformité** vous protège pendant **2 ans** à compter de la livraison L.217-3 L.217-4 L.217-5.  
      Vous pouvez exiger **réparation, remplacement ou remboursement gratuit**, sans condition et sans frais L.217-8 L.217-10 L.217-11.  
      Si la panne n’est pas réparée sous **30 jours**, ou si la solution est impossible, vous avez droit à une **réduction du prix** ou à la **résolution du contrat** L.217-13 L.217-14.

  - id: 'eligibilite'
    title: 'Quand la garantie s’applique'
    type: 'grid'
    items:
      - title: 'Panne ou défaut de fabrication'
        description: 'L’appareil ne fonctionne pas, fuit, chauffe mal, fait du bruit anormal ou ne correspond pas à la description L.217-4 L.217-5.'
      - title: 'Dans les 2 ans suivant l’achat'
        description: 'Le défaut apparaît dans les **24 mois** après la livraison : il est **présumé exister dès l’origine** L.217-7. Aucune expertise ne vous est demandée.'
      - title: 'Pas de mauvaise utilisation'
        description: 'Le défaut ne doit pas résulter d’un **mauvais usage** (surcharge, nettoyage incorrect, objet bloqué, etc.).'
      - title: 'Vendeur responsable'
        description: 'Vos démarches s’adressent toujours au **vendeur**, pas au fabricant L.217-3. Il ne peut pas vous imposer de passer par la marque.'

  - id: 'procedure'
    title: 'Procédure pas-à-pas'
    type: 'timeline'
    steps:
      - title: 'Contactez le vendeur'
        description: |
          Expliquez la panne, joignez la **facture** et décrivez le défaut.  
          Précisez que vous agissez au titre de la **garantie légale de conformité** L.217-3 à L.217-14.  
          Choisissez la **réparation** ou le **remplacement gratuit** L.217-8 L.217-11.
      - title: 'Délai de mise en conformité'
        description: |
          Le vendeur doit agir **sans frais** et **dans les 30 jours maximum** à compter de votre demande L.217-10.  
          Pendant la réparation, la garantie est **suspendue** L.217-16.
      - title: 'En cas d’impossibilité ou de retard'
        description: |
          Si la réparation est **impossible, disproportionnée ou dépasse 30 jours**, vous pouvez exiger une **réduction du prix** ou un **remboursement intégral** L.217-9 L.217-13 L.217-14.
      - title: 'Mise en demeure'
        description: |
          En cas de refus du vendeur, envoyez une **mise en demeure** avec rappel des articles L.217-8 à L.217-14.  
          Cela interrompt toute prescription et vous permettra d’agir ensuite en justice si besoin.

  - id: 'pieces-detachees'
    title: 'Pièces détachées et réparabilité'
    type: 'content'
    content: |
      Le vendeur doit vous informer **avant l’achat** de la disponibilité ou non des **pièces détachées** L.111-4.  
      Si cette information est absente ou fausse, vous pouvez invoquer un **défaut de conformité** L.217-5.  
      Les fabricants doivent également publier un **indice de réparabilité** et, depuis 2024, un **indice de durabilité** pour les appareils électroménagers.

  - id: 'cas-frequents'
    title: 'Cas fréquents'
    type: 'faq'
    faqItems:
      - q: 'Mon lave-linge tombe en panne après 18 mois'
        a: 'C’est une **non-conformité présumée d’origine** L.217-7. Le vendeur doit le réparer ou le remplacer gratuitement L.217-8 L.217-11.'
      - q: 'Le réparateur me facture le déplacement'
        a: 'C’est illégal : la mise en conformité doit être **sans frais** pour le consommateur L.217-11.'
      - q: 'Mon frigo est irréparable et le vendeur refuse le remplacement'
        a: 'S’il est impossible de réparer, le vendeur doit **rembourser intégralement** L.217-9 L.217-13 L.217-14.'
      - q: 'L’appareil réparé retombe en panne 2 mois après'
        a: 'La **garantie est prolongée** de la durée d’immobilisation du produit L.217-16. Le vendeur doit intervenir à nouveau sans frais.'

  - id: 'conseils'
    title: 'Bon à savoir'
    type: 'content'
    content: |
      - Un appareil **reconditionné** vendu par un professionnel bénéficie aussi de la garantie légale, avec une **présomption de 12 mois** L.217-7.  
      - Les **frais de transport, main-d’œuvre et pièces** sont intégralement à la charge du vendeur L.217-11.  
      - Un appareil en panne **ne peut pas être remplacé par un modèle reconditionné** sans votre accord explicite.  
      - Vous pouvez réclamer un **geste commercial** en plus du remboursement légal (bon d’achat, extension, etc.).

  - id: 'cta'
    title: 'Faites valoir vos droits'
    type: 'content'
    content: |
      Générez votre **réclamation ou mise en demeure** en ligne pour tout appareil électroménager défectueux.  
      Le texte cite automatiquement les **articles du Code de la consommation** adaptés à votre situation.  
      Version **PDF** et **envoi recommandé avec suivi** disponibles.
    cta:
      label: 'Rédiger ma réclamation'
      href: '/outils/mise-en-demeure'
      variant: 'primary'
      icon: 'FileText'

  - id: 'contacts'
    title: 'Contacts utiles'
    type: 'contacts'

  - id: 'disclaimer'
    title: 'Important'
    type: 'content'
    content: |
      Ce guide présente vos droits en matière d’**appareils électroménagers** selon le Code de la consommation.  
      Il **ne constitue pas un avis juridique individualisé**.  
      En cas de doute, contactez une **association de consommateurs** ou un **professionnel du droit**.

`,
  'vetements-et-accessoires-garantie-legale.yml': `title: 'Vêtements, chaussures, accessoires : vos droits en cas de défaut ou d’usure prématurée (Guide 2025)'
description: 'Couture qui lâche, semelle décollée, fermeture cassée, couleur qui déteint… La garantie légale de conformité protège tous vos achats de textile et d’accessoires pendant 2 ans. Réparation, remplacement ou remboursement : suivez le guide.'
category: 'mode'
slug: 'vetements-et-accessoires-garantie-legale'

seo:
  title: 'Vêtement ou chaussure défectueux : réparation ou remboursement gratuit (Guide 2025)'
  description: 'Couture déchirée, semelle décollée, accessoire abîmé ? Même sans garantie commerciale, la loi impose au vendeur de réparer, remplacer ou rembourser gratuitement pendant 2 ans. Tous vos droits selon les articles L.217-3 à L.217-14.'
  keywords:
    - 'vêtement défectueux garantie légale'
    - 'chaussure semelle décollée remboursement'
    - 'accessoire mode garantie conformité'
    - 'couture lâchée réparation vendeur'
    - 'L217-3 L217-4 L217-5 L217-13 garantie légale'
    - 'droit de rétractation textile achat en ligne'
    - 'bijou fantaisie défectueux échange'

legal:
  mainArticles:
    - 'L.217-3'
    - 'L.217-4'
    - 'L.217-5'
    - 'L.217-7'
    - 'L.217-8'
    - 'L.217-10'
    - 'L.217-11'
    - 'L.217-13'
    - 'L.217-14'
    - 'L.221-18'
    - 'L.221-23'
    - 'L.221-28'
  disclaimer: true
  lastUpdated: '2025-10-28'

sections:
  - id: 'intro'
    title: 'L’essentiel en 30 secondes'
    type: 'content'
    content: |
      Tout vêtement, chaussure ou accessoire acheté chez un **vendeur professionnel** doit être **conforme au contrat** L.217-3 L.217-4 L.217-5.  
      S’il présente un **défaut de fabrication**, une **usure anormale** ou ne correspond pas à ce qui était annoncé, vous pouvez exiger **réparation, remplacement ou remboursement gratuit** L.217-8 L.217-10 L.217-11.  
      La garantie légale s’applique pendant **2 ans après l’achat**, sans que vous ayez à prouver le défaut L.217-7.

  - id: 'eligibilite'
    title: 'Quand la garantie s’applique'
    type: 'grid'
    items:
      - title: 'Produit non conforme'
        description: 'Couture qui lâche, semelle qui se décolle, accessoire qui rouille ou déteint anormalement : le produit ne correspond pas aux qualités attendues L.217-4 L.217-5.'
      - title: 'Défaut dans les 2 ans'
        description: 'La panne ou l’usure prématurée apparaît dans les **24 mois** suivant l’achat : le défaut est **présumé exister à la livraison** L.217-7.'
      - title: 'Usage normal'
        description: 'Le défaut ne doit pas résulter d’un **mauvais entretien** ou d’une **utilisation inadaptée** (ex. lavage contraire aux consignes).'
      - title: 'Vendeur responsable'
        description: 'La garantie engage le **vendeur**, pas la marque ou le fabricant L.217-3. Vous n’avez aucune démarche à faire auprès de la marque.'

  - id: 'procedure'
    title: 'Procédure pas-à-pas'
    type: 'timeline'
    steps:
      - title: 'Rassemblez vos preuves'
        description: |
          Conservez le **ticket de caisse**, l’étiquette du produit et, si possible, des **photos du défaut**.  
          Mentionnez les **articles L.217-3 à L.217-14** dans votre courrier ou mail de réclamation.
      - title: 'Contactez le vendeur'
        description: |
          Adressez une **réclamation écrite** demandant la **mise en conformité gratuite** (réparation ou remplacement) L.217-8 L.217-11.  
          Si la boutique ou le site refuse, rappelez que la **preuve du défaut** ne vous incombe pas pendant 24 mois L.217-7.
      - title: 'Délai de 30 jours maximum'
        description: |
          Le vendeur doit agir **sans frais et sans retard excessif**, dans un **délai maximum de 30 jours** L.217-10.  
          Passé ce délai, vous pouvez exiger un **remboursement** ou une **réduction du prix** L.217-13 L.217-14.
      - title: 'En cas de refus'
        description: |
          Si le vendeur **refuse** ou **n’agit pas**, adressez-lui une **mise en demeure** rappelant ses obligations légales L.217-8 à L.217-14, puis saisissez le **médiateur** ou la **DGCCRF**.

  - id: 'achat-en-ligne'
    title: 'Achat en ligne : droit de rétractation'
    type: 'content'
    content: |
      Pour tout achat à distance, vous disposez d’un **délai de 14 jours** pour vous rétracter, même sans motif L.221-18.  
      Le vendeur doit rembourser dans les **14 jours suivant votre retour** L.221-23.  
      Ce droit ne s’applique pas aux produits **personnalisés**, **sur mesure** ou **descellés pour des raisons d’hygiène** (ex. maillots de bain, boucles d’oreilles) L.221-28.

  - id: 'cas-frequents'
    title: 'Cas fréquents'
    type: 'faq'
    faqItems:
      - q: 'La semelle de mes baskets s’est décollée après 3 mois'
        a: 'C’est une **usure anormale** couverte par la garantie légale L.217-3 à L.217-11. Le vendeur doit réparer ou remplacer gratuitement.'
      - q: 'La couleur de mon jean a déteint après un lavage conforme'
        a: 'Si les instructions d’entretien ont été respectées, c’est un **défaut de conformité** L.217-4 L.217-5. Vous pouvez exiger un échange ou un remboursement.'
      - q: 'Le magasin me renvoie vers la marque'
        a: 'C’est illégal : seul le **vendeur** est responsable envers vous L.217-3.'
      - q: 'J’ai acheté un sac “cuir véritable” qui s’abîme anormalement'
        a: 'Si la qualité réelle ne correspond pas à la description ou aux promesses commerciales, il y a **non-conformité** L.217-4 L.217-5.'

  - id: 'reconditionne'
    title: 'Articles d’occasion ou reconditionnés'
    type: 'content'
    content: |
      Les produits d’occasion vendus par un **professionnel** bénéficient aussi de la garantie légale de conformité, mais la **présomption** est réduite à **12 mois** L.217-7.  
      Vous pouvez demander **réparation, remplacement ou remboursement** selon la même procédure L.217-8 à L.217-14.  
      Pour un achat entre particuliers, la garantie légale ne s’applique pas — seul un **vice caché** peut être invoqué (articles 1641 et suivants du Code civil).

  - id: 'cta'
    title: 'Faites valoir vos droits'
    type: 'content'
    content: |
      Générez votre **réclamation ou mise en demeure** en ligne pour tout vêtement, chaussure ou accessoire défectueux.  
      Le texte intègre automatiquement les **articles du Code de la consommation** adaptés à votre situation.  
      Version **PDF professionnelle** et **envoi recommandé** disponibles.
    cta:
      label: 'Rédiger ma réclamation'
      href: '/outils/mise-en-demeure'
      variant: 'primary'
      icon: 'FileText'

  - id: 'contacts'
    title: 'Contacts utiles'
    type: 'contacts'

  - id: 'disclaimer'
    title: 'Important'
    type: 'content'
    content: |
      Ce guide résume vos droits en matière de **textile, mode et accessoires** selon le Code de la consommation.  
      Il **ne remplace pas** un avis juridique individualisé.  
      En cas de litige persistant, contactez une **association de consommateurs** ou un **professionnel du droit**.

`,
  'operateurs-telephonie-et-internet.yml': `title: 'Téléphonie, forfaits et opérateurs : vos droits en cas de problème (Guide 2025)'
description: 'Facture abusive, panne de réseau, refus de résiliation ou problème de portabilité ? Ce guide vous explique vos droits face à votre opérateur téléphonique, mobile ou internet, et les démarches pour obtenir réparation.'
category: 'numerique'
slug: 'operateurs-telephonie-et-internet'

seo:
  title: 'Problème avec un opérateur téléphonique : vos droits et recours (Guide 2025)'
  description: 'Panne, surfacturation, ligne coupée ou refus de résiliation ? Découvrez vos droits légaux face aux opérateurs téléphoniques et fournisseurs d’accès : obligations de service, remboursement, médiation, résiliation sans frais.'
  keywords:
    - 'opérateur téléphonique litige'
    - 'forfait mobile résiliation sans frais'
    - 'panne internet remboursement'
    - 'facture abusive téléphone'
    - 'portabilité numéro problème'
    - 'service client opérateur refus'
    - 'médiateur des communications électroniques'
    - 'L224-33 L224-39 L121-84'

legal:
  mainArticles:
    - 'L.121-84'
    - 'L.121-84-2'
    - 'L.224-33'
    - 'L.224-34'
    - 'L.224-39'
    - 'L.224-42'
    - 'L.224-44'
    - 'L.612-1'
    - 'L.616-1'
    - 'R.631-3'
    - 'L.34-8'
    - 'L.34-9'
  disclaimer: true
  lastUpdated: '2025-10-25'

sections:
  - id: 'intro'
    title: 'L’essentiel en 30 secondes'
    type: 'content'
    content: |
      Que vous soyez client **mobile, fixe ou internet**, votre opérateur doit vous fournir un service **conforme au contrat** et **fonctionnel en continu** L.224-33 L.224-39.  
      En cas de panne, coupure ou facturation abusive, vous pouvez obtenir **réparation**, **remboursement** ou **résiliation sans frais** L.121-84 L.224-42.  
      Si le service client refuse, un **médiateur spécialisé** peut trancher gratuitement L.612-1 L.616-1.

  - id: 'problemes-courants'
    title: 'Problèmes les plus fréquents'
    type: 'grid'
    items:
      - title: 'Coupures de réseau ou panne prolongée'
        description: 'L’opérateur doit assurer un **service continu**. Une panne prolongée justifie un **remboursement ou un geste commercial** L.224-33 L.224-39.'
      - title: 'Facture anormale ou surconsommation inexpliquée'
        description: 'Vous pouvez contester toute facturation manifestement erronée. L’opérateur doit **justifier les sommes réclamées** et suspendre le recouvrement en cas de contestation L.224-33.'
      - title: 'Résiliation impossible ou facturée à tort'
        description: 'Tout contrat peut être **résilié à tout moment après l’engagement**, ou sans frais en cas de **modification unilatérale** du contrat L.224-39 L.224-42.'
      - title: 'Numéro non transféré (portabilité bloquée)'
        description: 'La portabilité doit être réalisée en **1 jour ouvrable**. Tout retard injustifié donne droit à **indemnisation** L.34-8 L.34-9 du Code des postes et communications électroniques.'

  - id: 'procedure'
    title: 'Procédure pas-à-pas'
    type: 'timeline'
    steps:
      - title: 'Contactez le service client'
        description: |
          Expliquez le problème, précisez vos **numéro de contrat** et **dates concernées**, et gardez une **preuve écrite** (mail, chat, courrier).  
          Mentionnez vos droits à un **service conforme et continu** L.224-33 L.224-39.  
          L’opérateur doit répondre dans un **délai raisonnable**.
      - title: 'Réclamation écrite au service consommateurs'
        description: |
          En cas d’absence de réponse sous 30 jours, envoyez une **réclamation écrite** au **service consommateurs** de votre opérateur.  
          Citez les **articles L.224-33 et L.224-39** et précisez votre demande : remboursement, réparation, résiliation sans frais ou indemnisation.  
          Conservez l’accusé de réception.
      - title: 'Saisine du médiateur des communications électroniques'
        description: |
          Si aucune réponse sous 2 mois, saisissez gratuitement le **médiateur des communications électroniques** L.612-1 L.616-1.  
          Formulaire disponible sur [www.mediateur-telecom.fr](https://www.mediateur-telecom.fr).  
          Le médiateur rend un **avis motivé sous 90 jours**.  
          Cette démarche suspend toute procédure judiciaire.
      - title: 'Tribunal judiciaire en dernier recours'
        description: |
          Si le litige persiste, saisissez le **tribunal judiciaire de votre domicile** R.631-3.  
          Vous pouvez y demander **dommages et intérêts** en cas de coupure prolongée ou facturation abusive.

  - id: 'resiliation'
    title: 'Résiliation sans frais : vos cas de droit'
    type: 'content'
    content: |
      Vous pouvez résilier **sans pénalité** dans plusieurs situations prévues par la loi :
      - **Modification unilatérale du contrat** (tarif, conditions) L.224-39 L.224-42  
      - **Service non conforme ou coupure durable** L.224-33  
      - **Déménagement hors zone de couverture** si l’opérateur ne peut assurer le service  
      - **Force majeure ou décès du titulaire**  
      La résiliation doit être **effective sous 10 jours** après réception de votre demande L.224-42.  
      En cas de refus ou de facturation abusive, saisissez le **médiateur des communications électroniques** L.612-1.

  - id: 'facturation'
    title: 'Facturation et remboursement'
    type: 'content'
    content: |
      Toute facturation doit correspondre à un **service rendu** L.224-33.  
      En cas d’erreur, l’opérateur doit procéder au **remboursement intégral** sans frais ni délai excessif.  
      Si une coupure de réseau dure plusieurs jours, vous pouvez réclamer un **avoir au prorata** ou des **dommages et intérêts**.  
      Aucune **pénalité de retard** ne peut être appliquée pendant un litige en cours.

  - id: 'exemples'
    title: 'Cas concrets'
    type: 'content'
    content: |
      - **Résiliation après hausse de tarif** : l’opérateur doit vous prévenir **au moins 30 jours à l’avance** et vous pouvez refuser la modification en résiliant sans frais L.224-39 L.224-42.  
      - **Facturation après résiliation** : l’opérateur doit arrêter toute facturation dès la **date effective de résiliation**, sous peine de remboursement automatique L.121-84-2.  
      - **Réseau inopérant plusieurs jours** : la panne justifie un **remboursement partiel** ou une **résiliation anticipée sans frais** L.224-33.  
      - **Portabilité ratée** : vous pouvez exiger **indemnisation immédiate** selon le Code des postes et communications électroniques L.34-8 L.34-9.

  - id: 'faq'
    title: 'Questions fréquentes'
    type: 'faq'
    faqItems:
      - q: 'Puis-je contester une facture après paiement ?'
        a: 'Oui. Vous disposez d’un **délai de 12 mois** pour contester une facturation abusive L.224-33. L’opérateur doit fournir les justificatifs précis.'
      - q: 'Mon opérateur refuse de me rembourser une panne nationale'
        a: 'C’est illégal : la continuité du service est une **obligation légale** L.224-33. Vous pouvez exiger un remboursement au prorata de la période d’interruption.'
      - q: 'Je veux résilier mais mon opérateur me réclame des frais'
        a: 'Si vous êtes **hors période d’engagement**, tout frais est abusif L.121-84. Si vous êtes encore engagé, vérifiez si le motif entre dans les cas de résiliation légale sans frais L.224-42.'

  - id: 'cta'
    title: 'Passez à l’action'
    type: 'content'
    content: |
      Notre générateur de **réclamation télécom** vous aide à formuler votre demande : remboursement, résiliation, portabilité ou compensation.  
      Les textes du **Code de la consommation** et du **Code des postes et communications électroniques** sont insérés automatiquement.  
      Version **PDF** et **envoi recommandé** disponibles.
    cta:
      label: 'Rédiger ma réclamation opérateur'
      href: '/outils/reclamation-operateur'
      variant: 'primary'
      icon: 'FileText'

  - id: 'contacts'
    title: 'Contacts utiles'
    type: 'contacts'

  - id: 'disclaimer'
    title: 'Important'
    type: 'content'
    content: |
      Ce guide expose vos droits face aux **opérateurs de téléphonie et fournisseurs d’accès internet** selon le Code de la consommation et le Code des postes et communications électroniques.  
      Il **ne remplace pas** un avis juridique individualisé.  
      En cas de litige complexe, contactez le **Médiateur des communications électroniques** ou une **association agréée**.

`,
  'services-numeriques-garantie-legale.yml': `title: 'Services numériques, plateformes, abonnements : vos droits en cas de problème (Guide 2025)'
description: 'Streaming, jeux vidéo, applications, logiciels, cloud, formations en ligne… Tout service numérique doit être conforme au contrat. Réparation, mise à jour, résiliation ou remboursement : vos droits complets selon le Code de la consommation.'
category: 'numerique'
slug: 'services-numeriques-garantie-legale'

seo:
  title: 'Abonnement ou service numérique non conforme : vos droits (Guide 2025)'
  description: 'Bug, coupure, contenu inaccessible, promesse non tenue ? Découvrez vos droits légaux pour les services numériques : conformité, mises à jour, résiliation, remboursement. Guide complet avec modèles.'
  keywords:
    - 'service numérique non conforme'
    - 'streaming bug remboursement'
    - 'jeu vidéo en ligne garantie'
    - 'application défectueuse droits'
    - 'abonnement résiliation numérique'
    - 'mise à jour obligatoire L224-25-13'
    - 'L224-25-1 L224-25-14 L224-25-20'
    - 'conformité service numérique'

legal:
  mainArticles:
    - 'L.224-25-1'
    - 'L.224-25-2'
    - 'L.224-25-4'
    - 'L.224-25-5'
    - 'L.224-25-7'
    - 'L.224-25-10'
    - 'L.224-25-12'
    - 'L.224-25-13'
    - 'L.224-25-14'
    - 'L.224-25-20'
    - 'L.224-25-24'
    - 'L.224-25-27'
    - 'L.224-25-31'
  disclaimer: true
  lastUpdated: '2025-10-23'

sections:
  - id: 'intro'
    title: 'L’essentiel en 30 secondes'
    type: 'content'
    content: |
      Depuis 2022, la **garantie légale de conformité** s’applique aussi aux **services numériques** : streaming, jeux, logiciels, applications, cloud, formations en ligne ou abonnements.  
      Tout contenu ou service doit être **conforme au contrat** et **fonctionnel pendant toute la durée prévue** L.224-25-1 L.224-25-4.  
      En cas de bug, d’interruption injustifiée ou de promesse non tenue, vous pouvez obtenir **mise en conformité, réduction du prix ou résiliation sans frais** L.224-25-12 à L.224-25-14.

  - id: 'eligibilite'
    title: 'Quand la garantie s’applique'
    type: 'grid'
    items:
      - title: 'Service fourni contre paiement ou données'
        description: 'La garantie s’applique dès lors que vous avez payé ou fourni des **données personnelles** en échange du service L.224-25-2.'
      - title: 'Non-conformité'
        description: 'Le service ne correspond pas à ce qui était promis (fonctionnalités, compatibilité, qualité, disponibilité, sécurité) L.224-25-4 L.224-25-5.'
      - title: 'Durée de fourniture'
        description: 'Le professionnel doit maintenir la conformité **pendant toute la durée du contrat** (ex. abonnement) ou, pour un achat unique, pendant une durée **raisonnable** L.224-25-13.'
      - title: 'Responsable'
        description: 'Le **fournisseur du service** est responsable vis-à-vis du consommateur, même s’il dépend de sous-traitants ou plateformes tierces L.224-25-20.'

  - id: 'procedure'
    title: 'Que faire en cas de bug ou de défaut ?'
    type: 'timeline'
    steps:
      - title: 'Identifier le problème'
        description: |
          Notez la **date**, le **type d’anomalie** (ex. bug, indisponibilité, perte de données, promesse non tenue) et conservez des **captures d’écran**.  
          Cela facilitera la preuve du **défaut de conformité** L.224-25-5.
      - title: 'Contacter le service client'
        description: |
          Écrivez au fournisseur pour demander la **mise en conformité** du service (ex. correction du bug ou accès rétabli) **sans frais et dans un délai raisonnable** L.224-25-12 L.224-25-13.  
          Indiquez clairement le défaut et votre souhait (réparation ou remboursement).
      - title: 'Attendre la correction ou résilier'
        description: |
          Si le fournisseur ne corrige pas dans un **délai raisonnable**, vous pouvez exiger une **réduction du prix** ou **résilier sans frais** L.224-25-14.  
          Le remboursement doit intervenir dans un **délai maximum de 14 jours** L.224-25-27.
      - title: 'Conserver les preuves'
        description: |
          Gardez tous les mails, échanges et captures. Ils prouveront vos démarches si vous devez saisir un **médiateur** ou un **tribunal**.

  - id: 'maj'
    title: 'Mises à jour et compatibilité'
    type: 'content'
    content: |
      Le professionnel doit fournir les **mises à jour nécessaires au maintien de la conformité**, y compris de sécurité, pendant toute la durée du contrat L.224-25-13.  
      Si une mise à jour rend votre appareil incompatible, le fournisseur doit vous en informer **à l’avance** et proposer une solution L.224-25-14.  
      Refuser une mise à jour peut limiter vos droits si elle était **nécessaire au bon fonctionnement**.

  - id: 'resiliation'
    title: 'Résiliation et remboursement'
    type: 'content'
    content: |
      Si la non-conformité persiste, vous pouvez **résilier le contrat sans frais** L.224-25-14.  
      Le fournisseur doit **rembourser sous 14 jours** les sommes versées L.224-25-27.  
      Vous n’avez rien à payer pour la période postérieure à la résiliation, même en cas de forfait annuel.  
      Si le service était fourni partiellement, le remboursement est **proportionnel** à la durée d’inexécution.

  - id: 'exemples'
    title: 'Cas fréquents'
    type: 'faq'
    faqItems:
      - q: 'Mon application plante après une mise à jour'
        a: 'Le professionnel doit corriger le bug gratuitement et sans délai L.224-25-12. Si le problème persiste, vous pouvez exiger un remboursement L.224-25-14.'
      - q: 'La plateforme change ses fonctionnalités principales'
        a: 'Si la modification dégrade le service ou supprime une fonction essentielle, c’est une **non-conformité**. Vous pouvez demander la résiliation L.224-25-4 L.224-25-14.'
      - q: 'Je n’ai plus accès à un film ou à un jeu acheté en ligne'
        a: 'Le professionnel doit maintenir l’accès pendant la durée prévue du contrat. Sinon, vous pouvez exiger le rétablissement ou un remboursement L.224-25-5 L.224-25-14.'
      - q: 'Le service exige une nouvelle application payante'
        a: 'Si cela empêche l’accès au service initial, le vendeur manque à son obligation de conformité L.224-25-4 L.224-25-12.'

  - id: 'recours'
    title: 'Si le fournisseur refuse d’agir'
    type: 'timeline'
    steps:
      - title: 'Envoyer une mise en demeure'
        description: |
          Adressez-lui une **mise en demeure** rappelant les articles L.224-25-12 à L.224-25-14 et exigeant la mise en conformité ou le remboursement.  
          Fixez un **délai de 15 jours** pour obtenir une réponse.
      - title: 'Saisir un médiateur'
        description: |
          Si le fournisseur ne répond pas, vous pouvez saisir un **médiateur de la consommation** gratuitement L.612-1 L.616-1.  
          Joignez vos captures, échanges et le texte de votre mise en demeure.
      - title: 'Tribunal judiciaire'
        description: |
          En dernier recours, vous pouvez saisir le **tribunal judiciaire** de votre domicile R.631-3.  
          Pour un montant inférieur à 5 000 €, la procédure est **simple et sans avocat obligatoire**.

  - id: 'cta'
    title: 'Faites valoir vos droits en ligne'
    type: 'content'
    content: |
      Notre outil vous permet de générer automatiquement une **mise en demeure** adaptée aux services numériques, avec les **articles du Code de la consommation** insérés.  
      Versions **PDF** et **envoi recommandé** disponibles, avec **suivi et support illimité**.
    cta:
      label: 'Générer ma mise en demeure'
      href: '/outils/mise-en-demeure'
      variant: 'primary'
      icon: 'FileText'

  - id: 'contacts'
    title: 'Contacts utiles'
    type: 'contacts'

  - id: 'disclaimer'
    title: 'Important'
    type: 'content'
    content: |
      Ce guide présente les droits des consommateurs en matière de **services numériques et contenus en ligne** selon le Code de la consommation.  
      Il **ne remplace pas** un conseil juridique individuel.  
      En cas de doute ou de refus du fournisseur, contactez une **association agréée** ou un **juriste spécialisé**.

`,
  'voyage-et-loisirs-garantie-legale.yml': `title: 'Voyage, concert, spectacle ou box cadeau annulé : vos droits (Guide 2025)'
description: 'Annulation, report, prestation non conforme, refus de remboursement : vos droits sont garantis par le Code de la consommation. Ce guide vous explique la marche à suivre, selon le type de service ou de billet acheté.'
category: 'numerique'
slug: 'voyage-et-loisirs-garantie-legale'

seo:
  title: 'Annulation de voyage, concert ou box cadeau : remboursement ou avoir ? (Guide 2025)'
  description: 'Vol annulé, séjour modifié, spectacle reporté ou box cadeau inutilisable ? Découvrez vos droits à l’annulation, au remboursement ou à la compensation, selon les articles L.221-18, L.224-25-14 et L.211-16 du Code de la consommation.'
  keywords:
    - 'voyage annulé remboursement'
    - 'concert annulé remboursement légal'
    - 'box cadeau inutilisable droits consommateur'
    - 'L221-18 droit rétractation'
    - 'L224-25-14 non-conformité service'
    - 'voyage forfait agence annulation'
    - 'retard vol indemnisation'
    - 'spectacle report avoir obligatoire'

legal:
  mainArticles:
    - 'L.221-18'
    - 'L.221-23'
    - 'L.221-28'
    - 'L.224-25-12'
    - 'L.224-25-13'
    - 'L.224-25-14'
    - 'L.224-25-16'
    - 'L.211-14'
    - 'L.211-16'
    - 'R.211-10'
  disclaimer: true
  lastUpdated: '2025-10-31'

sections:
  - id: 'intro'
    title: 'L’essentiel en 30 secondes'
    type: 'content'
    content: |
      Vol annulé, concert reporté, hôtel fermé, box cadeau inutilisable : vos droits dépendent du type de service acheté.  
      Pour tout **achat à distance**, vous disposez d’un **délai de 14 jours pour vous rétracter** L.221-18, sauf exceptions prévues L.221-28.  
      Si le service est **non conforme**, partiellement exécuté ou annulé sans motif légitime, vous pouvez exiger un **remboursement ou une exécution conforme** L.224-25-14 L.224-25-16.  
      Les **voyages à forfait** bénéficient d’une protection renforcée : l’organisateur doit **rembourser intégralement** en cas d’annulation L.211-14 L.211-16.

  - id: 'types'
    title: 'Vos droits selon le type de service'
    type: 'grid'
    items:
      - title: 'Voyage à forfait (vol + hôtel)'
        description: 'Annulé ou modifié ? Vous pouvez demander un **remboursement intégral sans frais** L.211-14. Si le séjour est interrompu, l’organisateur doit **rapatrier** et **assister** les voyageurs L.211-16.'
      - title: 'Billet de concert ou spectacle'
        description: 'En cas d’annulation, l’organisateur doit **rembourser le prix du billet**, sauf report accepté. Les **avoirs imposés** ne sont plus légaux depuis 2023 L.224-25-14.'
      - title: 'Box cadeau ou bon non utilisable'
        description: 'Si le prestataire a fermé ou refuse d’honorer la box, l’émetteur doit **rembourser** ou **prolonger sa validité** L.224-25-14 L.224-25-16.'
      - title: 'Vol ou transport annulé'
        description: 'Les droits à indemnisation sont encadrés par les règlements européens (CE 261/2004). Vous pouvez exiger **remboursement ou réacheminement** sous 7 jours.'
      - title: 'Activité de loisir datée'
        description: 'Les réservations de loisirs à date fixe (ex. concert, musée, escape game) **ne sont pas rétractables** L.221-28. En revanche, en cas d’annulation par l’organisateur, un **remboursement intégral** est dû L.224-25-14.'

  - id: 'procedure'
    title: 'Procédure pas-à-pas'
    type: 'timeline'
    steps:
      - title: 'Identifiez le type de contrat'
        description: |
          Vérifiez si votre achat concerne un **service en ligne**, un **voyage à forfait**, une **prestation unique** ou une **activité datée**.  
          Les droits diffèrent selon les régimes applicables L.221-18 à L.221-28 et L.224-25-14.
      - title: 'Réclamation auprès du vendeur ou organisateur'
        description: |
          Envoyez un **courrier ou mail daté**, demandant le **remboursement intégral ou l’exécution conforme** selon L.224-25-14 L.224-25-16.  
          Précisez que la non-conformité résulte d’une **annulation, d’un défaut d’exécution ou d’une modification unilatérale**.
      - title: 'Délai de remboursement'
        description: |
          Le professionnel doit **rembourser sous 14 jours** maximum à compter de votre demande L.221-23.  
          Passé ce délai, des **intérêts de retard** peuvent être dus.
      - title: 'En cas de refus'
        description: |
          Envoyez une **mise en demeure** avec rappel des articles applicables L.224-25-14 et L.211-14, puis saisissez le **médiateur** ou la **DGCCRF**.  
          Vous pouvez également contester auprès du **centre européen des consommateurs (CEC France)** pour un achat transfrontalier.

  - id: 'cas-frequents'
    title: 'Cas fréquents'
    type: 'faq'
    faqItems:
      - q: 'L’agence me propose un avoir au lieu d’un remboursement'
        a: 'Refusez : les avoirs imposés ne sont plus autorisés depuis 2023. Vous avez droit à un **remboursement intégral** L.224-25-14.'
      - q: 'Le concert a été reporté et je ne peux pas y assister'
        a: 'Vous pouvez demander le **remboursement du billet**, même si la date de report est connue L.224-25-14.'
      - q: 'Ma box cadeau est expirée pendant la crise sanitaire'
        a: 'L’émetteur doit proposer une **prolongation de validité** ou un **remboursement** L.224-25-16.'
      - q: 'L’hôtel réservé en ligne n’existait pas ou n’était pas conforme'
        a: 'Vous pouvez réclamer le **remboursement intégral** pour **non-conformité du service** L.224-25-14, voire des dommages et intérêts en cas de préjudice.'

  - id: 'conseils'
    title: 'Bon à savoir'
    type: 'content'
    content: |
      - En cas de litige avec un professionnel basé dans l’UE, vous pouvez saisir gratuitement le **Centre européen des consommateurs France (CEC)**.  
      - Pour les **voyages à forfait**, conservez les échanges avec l’agence et les preuves de paiement : la **responsabilité de l’organisateur** est automatique L.211-16.  
      - Les **activités datées** (concerts, musées, festivals) n’ouvrent pas droit à rétractation L.221-28, mais doivent être **remboursées en cas d’annulation**.  
      - Si le service a été mal exécuté (ex. hôtel non conforme), vous pouvez exiger une **exécution correcte ou une réduction du prix** L.224-25-14.

  - id: 'cta'
    title: 'Faites valoir vos droits'
    type: 'content'
    content: |
      Générez votre **réclamation ou mise en demeure** pour tout voyage, concert, activité ou box cadeau annulé ou non conforme.  
      Votre courrier intégrera automatiquement les **articles de loi** adaptés à votre situation.  
      Version **PDF professionnelle** et **envoi recommandé** disponibles.
    cta:
      label: 'Rédiger ma réclamation'
      href: '/outils/mise-en-demeure'
      variant: 'primary'
      icon: 'FileText'

  - id: 'contacts'
    title: 'Contacts utiles'
    type: 'contacts'

  - id: 'disclaimer'
    title: 'Important'
    type: 'content'
    content: |
      Ce guide présente vos droits pour les **voyages, spectacles, activités et services de loisirs** selon le Code de la consommation.  
      Il **ne remplace pas** un conseil juridique individualisé.  
      En cas de litige complexe ou international, contactez un **médiateur**, la **DGCCRF** ou le **Centre européen des consommateurs France**.

`,
  'high-tech-garantie-legale.yml': `title: 'Ordinateurs, téléviseurs, consoles : vos droits en cas de panne (Guide 2025)'
description: 'PC, TV, console, tablette, appareil photo ou objet connecté en panne ? La garantie légale de conformité couvre la réparation, le remplacement ou le remboursement gratuit pendant 2 ans. Guide complet et modèles.'
category: 'tech'
slug: 'high-tech-garantie-legale'

seo:
  title: 'Ordinateur, TV ou console défectueux : garantie légale, 2 ans, remboursement (Guide 2025)'
  description: 'Votre appareil high-tech tombe en panne ? Vous avez droit à la réparation, au remplacement ou au remboursement gratuit selon la garantie légale de conformité. Découvrez la procédure complète et les modèles de lettres.'
  keywords:
    - 'ordinateur panne garantie légale'
    - 'TV défectueuse remplacement gratuit'
    - 'console de jeux garantie légale'
    - 'appareil photo problème conformité'
    - 'objet connecté dysfonctionnement garantie'
    - 'réparation remplacement remboursement 2 ans'
    - 'L217-3 L217-10 L217-13 garantie conformité'
    - 'vendeur refus prise en charge'

legal:
  mainArticles:
    - 'L.217-3'
    - 'L.217-4'
    - 'L.217-5'
    - 'L.217-7'
    - 'L.217-8'
    - 'L.217-9'
    - 'L.217-10'
    - 'L.217-11'
    - 'L.217-13'
    - 'L.217-14'
    - 'L.217-16'
    - 'L.217-19'
  disclaimer: true
  lastUpdated: '2025-10-27'

sections:
  - id: 'intro'
    title: 'L’essentiel en 30 secondes'
    type: 'content'
    content: |
      Qu’il s’agisse d’un **ordinateur, téléviseur, console, tablette ou appareil connecté**, votre vendeur doit livrer un produit **conforme au contrat** L.217-3 L.217-4 L.217-5.  
      En cas de panne ou de dysfonctionnement dans les **2 ans suivant l’achat**, vous avez droit à une **mise en conformité gratuite** : **réparation ou remplacement** L.217-8 L.217-11.  
      Si le problème persiste ou dépasse **30 jours**, vous pouvez demander une **réduction du prix** ou un **remboursement intégral** L.217-10 L.217-13 L.217-14.

  - id: 'eligibilite'
    title: 'Quand la garantie s’applique'
    type: 'grid'
    items:
      - title: 'Défaut de conformité'
        description: 'Le produit ne fonctionne pas comme prévu, ne correspond pas à la description ou présente un défaut de performance L.217-4 L.217-5.'
      - title: 'Délai de 2 ans'
        description: 'Le défaut apparaît dans les **24 mois** suivant la livraison (12 mois pour l’occasion) L.217-7. Le vendeur doit prouver une mauvaise utilisation pour refuser la prise en charge.'
      - title: 'Réparation ou remplacement gratuit'
        description: 'Le vendeur choisit la solution la plus adaptée mais **sans frais pour le consommateur** et **dans les 30 jours maximum** L.217-10 L.217-11.'
      - title: 'Logiciels et mises à jour inclus'
        description: 'Le vendeur doit fournir les **mises à jour nécessaires** au maintien de la conformité du produit L.217-19.'

  - id: 'procedure'
    title: 'Procédure pas-à-pas'
    type: 'timeline'
    steps:
      - title: 'Décrivez précisément la panne'
        description: |
          Notez les symptômes (ex. : écran noir, surchauffe, redémarrages, bruit, perte de Wi-Fi…) et les conditions d’apparition.  
          Ces éléments faciliteront la **preuve du défaut de conformité** L.217-4 L.217-5.
      - title: 'Contactez le vendeur'
        description: |
          Envoyez une réclamation claire demandant la **mise en conformité** par **réparation ou remplacement** L.217-8 L.217-11.  
          Mentionnez que le défaut est **présumé exister à la livraison** s’il apparaît dans les 24 mois L.217-7.
      - title: 'Respect du délai de 30 jours'
        description: |
          La mise en conformité doit être effectuée **dans un délai raisonnable n’excédant pas 30 jours** L.217-10.  
          Pendant la réparation, la garantie est **suspendue** L.217-16.
      - title: 'Échec ou refus du vendeur'
        description: |
          Si le vendeur **refuse**, tarde trop ou si la réparation est **impossible ou disproportionnée**, exigez une **réduction du prix** ou la **résolution du contrat** L.217-9 L.217-13 L.217-14.

  - id: 'reparations'
    title: 'Réparations et pièces détachées'
    type: 'content'
    content: |
      Le vendeur doit garantir la **disponibilité des pièces détachées** ou vous informer de leur absence avant l’achat L.111-4.  
      Depuis 2021, les fabricants doivent aussi fournir les **informations de réparabilité** et un **indice de durabilité**.  
      En cas d’indisponibilité non annoncée, vous pouvez invoquer la **non-conformité** L.217-5.

  - id: 'connectes'
    title: 'Objets connectés et logiciels embarqués'
    type: 'content'
    content: |
      Si votre appareil contient un logiciel ou nécessite des mises à jour, le vendeur doit **assurer leur maintien** pendant une période adaptée à la nature du bien L.217-19.  
      Si une mise à jour rend l’appareil inutilisable ou retire des fonctions essentielles, cela constitue une **non-conformité** L.217-5 L.217-19.  
      Vous pouvez exiger la **restauration du fonctionnement initial**, un **remplacement** ou un **remboursement**.

  - id: 'cas-frequents'
    title: 'Cas fréquents'
    type: 'faq'
    faqItems:
      - q: 'L’écran de ma TV s’éteint tout seul après 18 mois'
        a: 'Le défaut est **présumé antérieur** L.217-7. Le vendeur doit réparer ou remplacer gratuitement L.217-8 L.217-11.'
      - q: 'Ma console affiche un message d’erreur système'
        a: 'C’est une **non-conformité logicielle** si la panne empêche l’usage normal L.217-4 L.217-5 L.217-19.'
      - q: 'Le vendeur m’envoie vers le constructeur'
        a: 'C’est interdit : la **garantie légale** engage le **vendeur**, pas la marque L.217-3. Vous pouvez refuser d’être redirigé.'
      - q: 'Mon ordinateur réparé retombe en panne 3 mois plus tard'
        a: 'La garantie est **prolongée** de la durée d’immobilisation du produit L.217-16. Le vendeur doit intervenir à nouveau sans frais.'

  - id: 'reconditionne'
    title: 'Produits reconditionnés ou d’occasion'
    type: 'content'
    content: |
      Les appareils reconditionnés bénéficient de la **garantie légale de conformité**, mais la **présomption** est réduite à **12 mois** L.217-7.  
      Vous avez toujours droit à la **mise en conformité gratuite** et, à défaut, à la **réduction du prix** ou au **remboursement** L.217-8 à L.217-14.  
      Vérifiez que le vendeur est bien un **professionnel**, car la garantie légale **ne s’applique pas entre particuliers**.

  - id: 'cta'
    title: 'Faites valoir vos droits'
    type: 'content'
    content: |
      Générez gratuitement votre **réclamation ou mise en demeure** pour ordinateur, TV, console, tablette ou produit connecté.  
      Le courrier inclut automatiquement les **articles du Code de la consommation** adaptés à votre cas.  
      Version **PDF professionnelle** et **envoi recommandé** disponibles.
    cta:
      label: 'Générer ma réclamation'
      href: '/outils/mise-en-demeure'
      variant: 'primary'
      icon: 'FileText'

  - id: 'contacts'
    title: 'Contacts utiles'
    type: 'contacts'

  - id: 'disclaimer'
    title: 'Important'
    type: 'content'
    content: |
      Ce guide présente les droits du consommateur en matière de **produits électroniques et high-tech** selon le Code de la consommation.  
      Il **ne constitue pas un conseil juridique individualisé**.  
      En cas de litige complexe, contactez une **association de consommateurs** ou un **professionnel du droit**.

`,
  'smartphone-garantie-legale': `title: 'Téléphone en panne : vos droits et recours (Guide 2025)'
description: 'Même sans garantie constructeur, la loi vous protège : réparation, remplacement ou remboursement gratuit selon la garantie légale de conformité (articles L.217-3 et suivants). Procédure claire pas-à-pas + modèles.'
category: 'tech'
slug: 'telephonie-garantie-legale'

seo:
  title: 'Téléphone en panne : garantie légale, délai ≤ 30 jours, modèles (Guide 2025)'
  description: 'Votre téléphone ne fonctionne plus ? Même sans garantie constructeur, vous pouvez exiger réparation, remplacement ou remboursement gratuit selon la garantie légale de conformité L.217-3 à L.217-14. Nous vous accompagnons.'
  keywords:
    - 'téléphone panne garantie légale'
    - 'smartphone défectueux droits consommateur'
    - 'batterie smartphone garantie'
    - 'écran tactile micro haut-parleur défaut'
    - 'L.217-3 L.217-5 L.217-10 délai 30 jours'
    - 'réparation remplacement réduction résolution'
    - 'vendeur opérateur constructeur refus garantie'
    - 'smartphone reconditionné garantie légale'

legal:
  mainArticles:
    - 'L.217-3'
    - 'L.217-4'
    - 'L.217-5'
    - 'L.217-7'
    - 'L.217-8'
    - 'L.217-9'
    - 'L.217-10'
    - 'L.217-11'
    - 'L.217-12'
    - 'L.217-13'
    - 'L.217-14'
    - 'L.217-16'
    - 'L.217-19'
  disclaimer: true
  lastUpdated: '2025-10-10'

sections:
  - id: 'intro'
    title: 'L’essentiel en 30 secondes'
    type: 'content'
    content: |
      Votre vendeur doit vous livrer un téléphone conforme, c’est-à-dire qui fonctionne comme prévu L.217-3 L.217-4 L.217-5.

      Si une panne ou un défaut apparaît dans les 2 ans, vous pouvez exiger réparation ou remplacement gratuit L.217-8 L.217-11.

      En cas d’échec, de refus ou de dépassement du délai maximal de 30 jours, vous pouvez obtenir une réduction du prix ou un remboursement intégral L.217-10 L.217-13 L.217-14.

      Le défaut est présumé exister dès la livraison s’il apparaît dans les 24 mois (12 mois pour un produit d’occasion) L.217-7.

      Ces droits sont garantis par la loi et aucune preuve technique ne vous est demandée.

  - id: 'eligibilite'
    title: 'Êtes-vous éligible ?'
    type: 'grid'
    itemsIntro: 'Pour savoir si votre panne entre dans le champ de la garantie légale, vérifiez les quatre points suivants :'
    items:
      - title: 'Le téléphone présente un défaut'
        description: 'Batterie qui se vide vite, écran défaillant, micro ou haut-parleur inopérant, capteurs ou appareil photo défectueux, redémarrages répétés, performances très en-deçà des promesses. Voir L.217-4 L.217-5.'
      - title: 'Le défaut est apparu dans les 2 ans'
        description: '24 mois à compter de la délivrance (12 mois si occasion) : vous bénéficiez de la présomption légale L.217-7. Au-delà, vos droits demeurent mais la preuve vous incombe.'
      - title: 'Vous n’avez pas cassé ou mal utilisé l’appareil'
        description: 'Pas de mauvaise utilisation ni choc. La casse accidentelle est en principe exclue, sauf vice antérieur ou promesse de résistance non tenue L.217-5.'
      - title: 'C’est le vendeur, pas la marque, qui vous doit réparation'
        description: 'Vos démarches s’adressent au vendeur (magasin, site ou opérateur) L.217-3. Il ne peut pas vous imposer de traiter uniquement avec le constructeur.'

  - id: 'procedure'
    title: 'Procédure pas-à-pas'
    type: 'timeline'
    intro: |
      Voici les étapes à suivre pour faire valoir vos droits simplement et gratuitement.  
      Aucun avocat, aucune expertise technique : un courrier clair suffit à enclencher la procédure légale.
    steps:
      - title: '1) Rassembler les éléments utiles'
        description: |
          Conservez facture, IMEI, photos ou vidéos du défaut, échanges écrits, descriptif commercial (promesses), éventuels rapports SAV, et références des mises à jour reçues L.217-4 L.217-5 L.217-19.
        duration: '15–30 min'
      - title: '2) Réclamation écrite au vendeur'
        description: |
          Faites une réclamation courte et précise demandant la mise en conformité gratuite selon votre choix : réparation ou remplacement L.217-8 L.217-11.  
          Mentionnez que le défaut est présumé antérieur s’il est apparu dans les 24 ou 12 mois L.217-7.  
          Demandez un accusé écrit avec un délai d’exécution raisonnable conforme à la loi.
        duration: '10 min'
      - title: '3) Mise en conformité ≤ 30 jours'
        description: |
          Le vendeur doit agir sans frais et sans inconvénient majeur L.217-11.  
          Délai maximal : la mise en conformité doit intervenir dans un délai raisonnable ne pouvant excéder 30 jours à compter de votre demande L.217-10.  
          L’immobilisation de l’appareil suspend la garantie pendant cette période L.217-16.
        duration: 'variable (souvent < 30 jours)'
      - title: '4) Si échec, refus ou dépassement du délai'
        description: |
          Si le vendeur refuse, ne répond pas, ou dépasse les 30 jours, réclamez une réduction du prix ou la résolution du contrat (remboursement) L.217-9 L.217-10 L.217-13 L.217-14.  
          Mentionnez les articles applicables dans votre courrier pour renforcer votre demande.
        duration: '10 min'

  - id: 'table-remedies'
    title: 'Vos options selon la situation'
    type: 'table'
    intro: 'Selon la gravité du défaut et la réponse du vendeur, la loi prévoit quatre solutions possibles :'
    tableData:
      - 'Option': 'Réparation'
        'Quand ?': 'Défaut réparable, pièces disponibles'
        'Coût pour vous': '0 € L.217-11'
        'Délai': '≤ 30 jours à compter de votre demande L.217-10'
        'Précisions': 'Suspension de la garantie pendant immobilisation L.217-16'
      - 'Option': 'Remplacement'
        'Quand ?': 'Défaut majeur ou réparation impossible/disproportionnée'
        'Coût pour vous': '0 € L.217-11'
        'Délai': '≤ 30 jours à compter de votre demande L.217-10'
        'Précisions': 'Sans inconvénient majeur L.217-11'
      - 'Option': 'Réduction du prix'
        'Quand ?': 'Si mise en conformité impossible, échoue, est refusée ou dépasse 30 jours'
        'Coût pour vous': '—'
        'Délai': 'Exécution rapide après accord'
        'Précisions': 'Proportionnelle à l’écart de conformité L.217-13'
      - 'Option': 'Résolution (remboursement)'
        'Quand ?': 'Défaut grave, refus ou dépassement du délai de 30 jours'
        'Coût pour vous': '—'
        'Délai': 'Après restitution de l’appareil'
        'Précisions': 'Remboursement total (ou partiel si usage notable) L.217-14'

  - id: 'exceptions'
    title: 'Cas fréquents contestés'
    type: 'faq'
    intro: 'Voici les situations les plus souvent discutées par les vendeurs, et ce que dit la loi.'
    faqItems:
      - q: 'Écran fissuré : couvert par la garantie légale ?'
        a: 'En principe non (accident). Sauf vice antérieur ou promesse de résistance spécifique non tenue L.217-5.'
      - q: 'Le vendeur me renvoie vers le constructeur'
        a: 'La garantie légale engage le vendeur L.217-3. Un SAV constructeur peut être proposé sans vous faire renoncer à vos droits.'
      - q: 'Batterie qui se décharge très vite'
        a: 'Si l’autonomie est nettement en-deçà d’un usage normal ou des promesses, cela caractérise un défaut de conformité L.217-4 L.217-5.'
      - q: 'Appareil d’occasion'
        a: 'Présomption 12 mois L.217-7. Droits identiques : mise en conformité gratuite, puis réduction ou résolution en cas d’échec.'
      - q: 'Pièces indisponibles'
        a: 'Si la réparation est impossible, exigez le remplacement, puis à défaut réduction ou résolution L.217-9 L.217-13 L.217-14.'

  - id: 'exemples'
    title: 'Exemples concrets'
    type: 'content'
    content: |
      - Achat chez un opérateur (SFR, Orange, Bouygues, Free) : c’est l’opérateur vendeur qui doit réparer ou remplacer le produit. Il ne peut pas vous imposer de contacter la marque L.217-3.  
      - Marketplace (Amazon, Cdiscount, Fnac Marketplace) : la garantie légale s’exerce contre le vendeur tiers. Si celui-ci ne répond pas, la plateforme peut rester impliquée selon son rôle effectif dans la vente.  
      - Reconditionné : mêmes droits que le neuf (présomption 12 mois), y compris mise en conformité gratuite L.217-7 L.217-8 à L.217-11.  
      - Refus de prise en charge injustifié : si le vendeur invoque une mauvaise utilisation sans preuve, il est en tort. Il lui revient de prouver l’origine du défaut L.217-7.

  - id: 'cta-lettre'
    title: 'Passez à l’action'
    type: 'content'
    content: |
      En 3 minutes, générez gratuitement votre lettre de réclamation prête à envoyer au vendeur.  
      Le texte cite automatiquement les articles du Code de la consommation et s’adapte à votre situation.  
      Version PDF professionnelle avec signature en ligne ou envoi recommandé avec suivi disponibles.
    cta:
      label: 'Générer gratuitement ma lettre'
      href: '/outils/mise-en-demeure'
      variant: 'primary'
      icon: 'FileText'

  - id: 'alternatives'
    title: 'Si la garantie légale ne s’applique pas'
    type: 'alternatives'
    intro: 'Si votre appareil n’entre pas dans le champ de la garantie (ex. choc, mauvais usage, achat entre particuliers), vous avez d’autres recours amiables possibles.'

  - id: 'contacts'
    title: 'Contacts utiles'
    type: 'contacts'

  - id: 'disclaimer'
    title: 'Important'
    type: 'content'
    content: |
      Ce guide fournit une information juridique générale issue du Code de la consommation.  
      Il ne constitue pas un conseil juridique individualisé.  
      En cas de doute, contactez un professionnel du droit ou une association de consommateurs.
`
};

/**
 * Métadonnées de génération
 */
export const GENERATION_META = {
  timestamp: '2025-11-22T09:40:45.735Z',
  totalGuides: 12,
  buildScript: 'scripts/build-guides.js'
};

/**
 * Liste de tous les slugs disponibles
 */
export const ALL_GUIDE_SLUGS = [
  'vehicules-garantie-legale-vices-caches.yml',
  'grandes-enseignes-et-marketplaces.yml',
  'garantie-legale-conformite-guide-complet',
  'recours-apres-mise-en-demeure.yml',
  'recours-non-eligible.yml',
  'electromenager-garantie-legale.yml',
  'vetements-et-accessoires-garantie-legale.yml',
  'operateurs-telephonie-et-internet.yml',
  'services-numeriques-garantie-legale.yml',
  'voyage-et-loisirs-garantie-legale.yml',
  'high-tech-garantie-legale.yml',
  'smartphone-garantie-legale'
];
