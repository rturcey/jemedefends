export { default as HomePageSchema } from './HomePageSchema';
